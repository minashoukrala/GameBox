

let lastRender = 0;
let fps = 5;
let testMode = true;

//---Menu---------------------------
function showWinScreen() {
    document.getElementById("win-screen").style.display = "flex";
    startConfetti();
}

function showLoseScreen() {
    document.getElementById("lose-screen").style.display = "flex";
    stopConfetti();
}

function returnToMenu() {
    document.getElementById('win-screen').style.display = 'none';
    document.getElementById('lose-screen').style.display = 'none';
    document.getElementById('menu-overlay').style.display = 'flex';
    stopConfetti();
    resetGame();
}

//------------------------------------------
// 🎉 Confetti!
const confettiCanvas = document.getElementById("confetti-canvas");
const confettiCtx = confettiCanvas.getContext("2d");

let confettiPieces = [];
let confettiActive = false;

function createConfettiPiece() {
    return {
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight - 20,
        radius: Math.random() * 6 + 4,
        color: `hsl(${Math.random() * 360}, 100%, 70%)`,
        speedX: Math.random() * 2 - 1,
        speedY: Math.random() * 3 + 2,
        opacity: Math.random() * 0.5 + 0.5
    };
}

function drawConfetti() {
    confettiCtx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
    for (let i = 0; i < confettiPieces.length; i++) {
        const p = confettiPieces[i];
        confettiCtx.beginPath();
        confettiCtx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        confettiCtx.fillStyle = p.color;
        confettiCtx.globalAlpha = p.opacity;
        confettiCtx.fill();
        confettiCtx.closePath();
        p.x += p.speedX;
        p.y += p.speedY;
        if (p.y > window.innerHeight) {
            p.y = -10;
            p.x = Math.random() * window.innerWidth;
        }
    }
    confettiCtx.globalAlpha = 1.0;
    if (confettiActive) {
        requestAnimationFrame(drawConfetti);
    }
}

function startConfetti() {
    confettiCanvas.width = window.innerWidth;
    confettiCanvas.height = window.innerHeight;
    confettiPieces = new Array(150).fill().map(createConfettiPiece);
    confettiActive = true;
    drawConfetti();
}

function stopConfetti() {
    confettiActive = false;
    confettiCtx.clearRect(0, 0, confettiCanvas.width, confettiCanvas.height);
}


//----------------------------------------------


function setMode(mode) {
    if (mode === 'easy') {
        fps = 5;
        testMode = true;
    } else if (mode === 'medium') {
        fps = 5;
        testMode = false;
    } else if (mode === 'hard') {
        fps = 10;
        testMode = false;
    }
    document.getElementById('menu-overlay').style.display = 'none';
    window.requestAnimationFrame(main);
}




function main(currentTime) {
    window.requestAnimationFrame(main);
    const secondsSinceLastRender = (currentTime - lastRender)/1000;
    
    if (secondsSinceLastRender < 1/fps) {
        return;
    }
    lastRender = currentTime;

    draw();
}

window.requestAnimationFrame(main);


function draw() {
    gameBoard.innerHTML = "";
    updatePos();
    drawSnake();
    drawBananas();
}

const gameBoard = document.getElementById("game-board");
const Score = document.getElementById("score");
const Highscore = document.getElementById("highscore");
const Fullscreen = document.getElementById("fullscreen");
const Restart = document.getElementById("restart");


let snakePos = [{x:4, y:8, rotation: 0}, {x:5, y:8, rotation: 0}, {x:6, y:8, rotation: 0}];

let numOfBananas = 5;
let bananaPos = [];
setBananaPos();
let hasSpace = true;
let win = false;
let score = 0;
let highscore = 0;
let color = [137, 207, 240];


function drawSnake() {
    // tail
    const tailElement = document.createElement("div");
    tailElement.classList.add("square");
    tailElement.style.gridColumnStart = snakePos[0].x;
    tailElement.style.gridRowStart = snakePos[0].y;
    tailElement.style.backgroundColor = `rgb(${color[0]}, ${color[1]}, ${color[2]})`;
    gameBoard.appendChild(tailElement);

    // body
    for (i = 1; i < snakePos.length - 1; i++) {
        const bodyElement = document.createElement("div");
        bodyElement.classList.add("square");
        bodyElement.style.gridColumnStart = snakePos[i].x;
        bodyElement.style.gridRowStart = snakePos[i].y;
        // color
        const percentage = i / (snakePos.length - 1);
        const r = Math.round(color[0] + (76 - color[0]) * percentage);
        const g = Math.round(color[1] + (123 - color[1]) * percentage);
        const b = Math.round(color[2] + (240 - color[2]) * percentage);
        bodyElement.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;
        gameBoard.appendChild(bodyElement);
    }

    // head
    const headElement = document.createElement("div");
    headElement.classList.add("square");
    headElement.style.gridColumnStart = snakePos[snakePos.length - 1].x;
    headElement.style.gridRowStart = snakePos[snakePos.length - 1].y;
    headElement.style.backgroundColor = `rgb(76, 123, 240)`;
    gameBoard.appendChild(headElement);
    
    // eyes
    const eyesElement = document.createElement("div");
    eyesElement.classList.add("snakeEyes");
    eyesElement.style.gridColumnStart = snakePos[snakePos.length - 1].x;
    eyesElement.style.gridRowStart = snakePos[snakePos.length - 1].y;
    eyesElement.style.transform = `rotate(${snakePos[snakePos.length - 1].rotation}deg)`;
    headElement.appendChild(eyesElement);
}

function drawBananas() {
    bananaPos.forEach(banana => {
        const bananaElement = document.createElement("div");
        bananaElement.classList.add("banana");
        bananaElement.style.gridColumnStart = banana.x;
        bananaElement.style.gridRowStart = banana.y;
        gameBoard.appendChild(bananaElement);
    });
}

let dx = 0;
let dy = 0;

function updatePos() {
    // move all segments
    if (!(dx === 0 && dy === 0)) {
        for(let i = 0; i < snakePos.length - 1; i++){
            snakePos[i].x = snakePos[i+1].x;
            snakePos[i].y = snakePos[i+1].y;
            snakePos[i].rotation = snakePos[i+1].rotation;
        }
        if (dx === 1 && dy === 0) {
            snakePos[snakePos.length - 1].rotation = 0;
        } else if (dx === 0 && dy === 1) {
            snakePos[snakePos.length - 1].rotation = 90;
        } else if (dx === -1 && dy === 0) {
            snakePos[snakePos.length - 1].rotation = 180;
        } else if (dx === 0 && dy === -1) {
            snakePos[snakePos.length - 1].rotation = 270;
        }
        snakePos[snakePos.length - 1].x += dx;
        snakePos[snakePos.length - 1].y += dy;
    }

    if (!testMode) {
        if (snakePos[snakePos.length - 1].x < 1 || snakePos[snakePos.length - 1].x > 16 || snakePos[snakePos.length - 1].y < 1 || snakePos[snakePos.length - 1].y > 16) {
            showLoseScreen();
            return;
        }
        for (let i = 0; i < snakePos.length - 1; i++) {
            if (snakePos[snakePos.length - 1].x === snakePos[i].x && snakePos[snakePos.length - 1].y === snakePos[i].y) {
                showLoseScreen();
                return;
            }
        }
    }
    
    else {
        if (snakePos[snakePos.length - 1].x < 1) {
            snakePos[snakePos.length - 1].x = 16;
        }
        if (snakePos[snakePos.length - 1].x > 16) {
            snakePos[snakePos.length - 1].x = 1;
        }
        if (snakePos[snakePos.length - 1].y < 1) {
            snakePos[snakePos.length - 1].y = 16;
        }
        if (snakePos[snakePos.length - 1].y > 16) {
            snakePos[snakePos.length - 1].y = 1;
        }
    }
    
    checkIfFull();
    // if it touches a banana
    for (let i = 0; i < bananaPos.length; i++) {
        if (snakePos[snakePos.length - 1].x === bananaPos[i].x && snakePos[snakePos.length - 1].y === bananaPos[i].y) {
            addSegment();
            moveBanana(i);
            score+=1;
        }
    }
    checkIfWon();
    Score.innerHTML = score;
    if (score > highscore) {
        highscore = score;
    }
    Highscore.innerHTML = highscore;
}

function addSegment() {
    let newSegment = {x: snakePos[0].x, y: snakePos[0].y, rotation: snakePos[0].rotation};
    snakePos.unshift(newSegment);
}

function resetGame(showEnd = false) {
    dx = 0;
    dy = 0;
    snakePos = [{x:4, y:8, rotation: 0}, {x:5, y:8, rotation: 0}, {x:6, y:8, rotation: 0}];
    bananaPos = [];
    setBananaPos();
    hasSpace = true;
    win = false;
    if (score !== 0 && !showEnd) {
        Highscore.style.visibility = "visible";
        document.getElementById("trophy").style.visibility = "visible";
    }
    score = 0;
    Score.innerHTML = score;
}


function moveBanana(i) {
    let newBanana = {};
    let validPosition = false;
    while (validPosition === false && hasSpace === true) {
        validPosition = true;
        newBanana = {
            x: Math.floor(Math.random() * 16) + 1,
            y: Math.floor(Math.random() * 16) + 1,
        };

        for (let j = 0; j < snakePos.length; j++) {
            if (newBanana.x === snakePos[j].x && newBanana.y === snakePos[j].y) {
                validPosition = false;
                break;
            }
        }

        for (let j = 0; j < bananaPos.length; j++) {
            if (i !== j && newBanana.x === bananaPos[j].x && newBanana.y === bananaPos[j].y) {
                validPosition = false;
                break;
            }
        }
    }

    bananaPos[i] = newBanana;
}

function checkIfFull() {
    hasSpace = true;
    if (snakePos.length - 1 + bananaPos.length - 1 >= 256) {
        hasSpace = false;
    }
}

function checkIfWon() {
    if (snakePos.length - 1 >= 256) {
        win = true;
        dx = 0;
        dy = 0;
        showWinScreen();
    }
}


function setBananaPos() {
    if (numOfBananas === 1) {
        bananaPos = [{x:13, y:8}];
    }
    else if (numOfBananas === 2) {
        bananaPos = [{x:12, y:7}, {x:12, y:9}];
    }
    else if (numOfBananas === 3) {
        bananaPos = [{x:11, y:6}, {x:11, y:10}, {x:13, y:8}];
    }
    else if (numOfBananas === 4) {
        bananaPos = [{x:13, y:7}, {x:13, y:9}, {x:11, y:9}, {x:11, y:7}];
    }
    else if (numOfBananas === 5) {
        bananaPos = [{x:12, y:8}, {x:14, y:6}, {x:14, y:10}, {x:10, y:10}, {x:10, y:6}];
    }
    else {
        for (let i = 0; i < numOfBananas; i++) {
            bananaPos.push({x:16, y:3});
        }
    }
}

document.addEventListener("keydown", (event) => {
    switch (event.key) {
        case "ArrowUp":
            if (!(dx === 0 && dy === 0) && snakePos[snakePos.length - 1].rotation === 270 && !win) {
                break;
            }
            if (snakePos[snakePos.length - 1].rotation !== 90 && !win) {
                dx = 0;
                dy = -1;
            }
            break;
        case "ArrowDown":
            if (!(dx === 0 && dy === 0) && snakePos[snakePos.length - 1].rotation === 90 && !win) {
                break;
            }
            if (snakePos[snakePos.length - 1].rotation !== 270 && !win) {
                dx = 0;
                dy = 1;
            }
            break;
        case "ArrowLeft":
            if (!(dx === 0 && dy === 0) && snakePos[snakePos.length - 1].rotation === 180 && !win) {
                break;
            }
            if (snakePos[snakePos.length - 1].rotation !== 0 && !win) {
                dx = -1;
                dy = 0;
            }
            break;
        case "ArrowRight":
            if (!(dx === 0 && dy === 0) && snakePos[snakePos.length - 1].rotation === 0 && !win) {
                break;
            }
            if (snakePos[snakePos.length - 1].rotation !== 180 && !win) {
                dx = 1;
                dy = 0;
            }
            break;
        case "Enter":
            dx = 0;
            dy = 0;
            break;
    }
});

Fullscreen.addEventListener("click", () => {
    if (document.fullscreenElement) {
        document.exitFullscreen();
        document.querySelector('#fullscreen path').setAttribute('d', 'M112-112v-218h97v121h121v97H112Zm518 0v-97h121v-121h97v218H630ZM112-630v-218h218v97H209v121h-97Zm639 0v-121H630v-97h218v218h-97Z');
      } else {
        document.documentElement.requestFullscreen();
        document.querySelector('#fullscreen path').setAttribute('d', 'M233-112v-121H112v-97h218v218h-97Zm397 0v-218h218v97H727v121h-97ZM112-630v-97h121v-121h97v218H112Zm518 0v-218h97v121h121v97H630Z');
      }
});

Restart.addEventListener("click", () => {
    resetGame();
    Restart.style.transition = 'transform 0.3s ease-in-out';
    Restart.style.transform = 'rotate(-360deg)';

    Restart.addEventListener('transitionend', () => {
        Restart.style.transition = 'none';
        Restart.style.transform = 'rotate(0deg)';
    });
});